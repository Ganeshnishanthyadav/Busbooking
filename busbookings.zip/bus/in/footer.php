<footer>
        &copy; 2023 Bus Ticketing System
    </footer>