<header>
        <h1>Bus Ticketing System</h1>
    </header>