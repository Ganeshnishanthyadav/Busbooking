<?php
if(isset($_SESSION['usertype'])){
        $user=$_SESSION['usertype'];
}else{
        $user='';
}
if($user=='User'){
?>
        <nav>
                <a href="index.php">Home</a>
                <a href="checkavailability_user.php">Check Bus Availability</a>
                <a href="viewbookings.php">View Bookings</a>
                <a href="verify.php">Verify Booking</a>
                <a href="logout.php">Logout</a>
        </nav>
<?php
}else if($user=='Admin'){
?>
        <nav>
                <a href="index.php">Home</a>
                <a href="busstops.php">Add Bus Stops</a>
                <a href="addbus.php">Add Bus</a>
                <a href="viewbuses.php">View Buses</a>
                <a href="viewbookings_admin.php">View Bookings</a>
                <a href="logout.php">Logout</a>
        </nav>
<?php
}else{
?>
        <nav>
                <a href="index.php">Home</a>
                <a href="checkavailability.php">Check Bus Availability</a>
                <a href="login.php">Login</a>
                <a href="signup.php">Signup</a>
        </nav>
<?php
}
?>