<?php
include('in/session.php');
include('in/con.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php 
        include('in/head.php');
    ?>
    <style>
        /* Resetting some default browser styles */
        body, h1, h2, h3, p {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f6f8;
            color: #3a3a3a;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background: linear-gradient(45deg, #1a1a2e, #16213e);
            color: #e0e0e0;
            padding: 30px 0;
            text-align: center;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }

        nav {
            display: flex;
            justify-content: space-around;
            padding: 20px 0;
            background-color: #fff;
            box-shadow: 0px 2px 15px rgba(0, 0, 0, 0.08);
        }

            nav a {
                color: #5a5a5a;
                padding: 0 10px;
                text-decoration: none;
                font-weight: 500;
                transition: color 0.3s;
            }

                nav a:hover {
                    color: #333;
                }

        .main-content {
            flex: 1;
            padding: 10px;
            margin-top: 20px;
            text-align: center;
        }

        .search-form {
            max-width: 500px;
            margin: 20px auto 40px auto;
        }

        .search-bar {
            display: flex;
            border: 1px solid #ccc;
            border-radius: 50px;
            overflow: hidden;
            background-color: #fff;
        }

            .search-bar input {
                flex: 1;
                padding: 15px 20px;
                border: none;
                font-size: 1em;
                outline: none;
            }

            .search-bar button {
                padding: 15px 20px;
                border: none;
                background-color: #007bff;
                color: #fff;
                cursor: pointer;
                border-radius: 0 50px 50px 0;
                transition: background-color 0.3s;
            }

                .search-bar button:hover {
                    background-color: #0056b3;
                }

        /* Table Styles */
        table {
            max-width: 800px;
            margin: 40px auto;
            border-collapse: collapse;
            width: 100%;
        }

            table th, table td {
                border: 1px solid #ccc;
                padding: 10px 15px;
            }

            table th {
                background-color: #f4f6f8;
                color: #333;
            }

        /* Action buttons */
        button, .action-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            outline: none;
        }

        .search-bar button {
            background-color: #007bff;
            color: #fff;
        }

            .search-bar button:hover {
                background-color: #0056b3;
                transform: scale(1.05); /* Slightly enlarges the button */
                box-shadow: 3px 3px 15px rgba(0, 56, 179, 0.2);
            }

        .action-btn {
            padding: 7px 10px;
            border: none;
            cursor: pointer;
            transition: transform 0.3s;
            border-radius: 4px;
        }

            .action-btn.edit {
                background-color: #4CAF50;
                color: white;
                margin-right: 10px; /* Space between the buttons */
                margin-bottom: 10px;
            }

                .action-btn.edit:hover {
                    transform: translateY(-2px) scale(1.1);
                }

                .action-btn.edit:before {
                    content: "\f044"; /* Font Awesome Edit Icon */
                    font-family: "Font Awesome 5 Free";
                    padding-right: 5px;
                    font-weight: 900;
                }

            .action-btn.delete {
                background-color: #f44336;
                color: white;
            }

                .action-btn.delete:hover {
                    transform: translateY(-2px) scale(1.1);
                }

                .action-btn.delete:before {
                    content: "\f2ed"; /* Font Awesome Trash Alt Icon */
                    font-family: "Font Awesome 5 Free";
                    padding-right: 5px;
                    font-weight: 900;
                }

        footer {
            background-color: #1a1a2e;
            color: #e0e0e0;
            text-align: center;
            padding: 30px 0;
        }

        body, h1, h2, h3, p, label, input, textarea {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f6f8;
            color: #3a3a3a;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background: linear-gradient(45deg, #1a1a2e, #16213e);
            color: #e0e0e0;
            padding: 30px 0;
            text-align: center;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }

        nav {
            display: flex;
            justify-content: space-around;
            padding: 20px 0;
            background-color: #fff;
            box-shadow: 0px 2px 15px rgba(0, 0, 0, 0.08);
        }

            nav a {
                color: #5a5a5a;
                padding: 0 10px;
                text-decoration: none;
                font-weight: 500;
                transition: color 0.3s;
            }

                nav a:hover {
                    color: #333;
                }

        .banner {
            flex: 1;
            background-color: #f4f6f8;
            padding: 80px 0;
            text-align: center;
        }

        .submit-form {
            max-width: 450px;
            margin: 0 auto;
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .field {
            position: relative;
            margin-bottom: 40px;
        }

            .field input, .field textarea,  select {
                width: 100%;
                border: 1px solid #ccc;
                padding: 20px;
                border-radius: 5px;
                background-color: #f4f6f8;
                transition: 0.3s;
                font-size: 16px;
            }

            .field label {
                position: absolute;
                left: 20px;
                top: 50%;
                transform: translateY(-50%);
                background-color: #fff;
                padding: 0 10px;
                transition: 0.3s;
            }

            .field input:focus + label, .field textarea:focus + label,
            .field input:valid + label, .field textarea:valid + label {
                top: -15px;
                font-size: 12px;
                color: #007bff;
            }

        .submit-form button {
            width: 100%;
            padding: 15px 0;
            border: none;
            border-radius: 6px;
            background-image: linear-gradient(45deg, #3498db, #8e44ad);
            font-size: 18px;
            color: #fff;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

            .submit-form button:before {
                content: "";
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background-color: rgba(255, 255, 255, 0.1);
                transition: all 0.3s;
                pointer-events: none;
                z-index: -1;
            }

            .submit-form button:hover {
                box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
                transform: translateY(-3px);
                background: linear-gradient(45deg, #3a7bd5, #9b59b6);
            }

                .submit-form button:hover:before {
                    left: 100%;
                }


        footer {
            background-color: #1a1a2e;
            color: #e0e0e0;
            text-align: center;
            padding: 30px 0;
        }

        table {
            max-width: 800px;
            margin: 40px auto;
            border-collapse: collapse;
            width: 100%;
        }

            table th, table td {
                border: 1px solid #ccc;
                padding: 10px 15px;
            }

            table th {
                background-color: #f4f6f8;
                color: #333;
            }
    </style>
</head>

<body>
    <?php 
        include('in/header.php');
        include('in/nav.php');
    ?>
<div class="banner">
        <div class="submit-form">
            <form  method="post">
                <div class="field form-group">
                    <h2>Check Availability</h2>
                </div>
                <div class="field form-group">
                    
                    <div class="field form-group">
                        <select class="form-control" name="bus_from">
                            <?php 
                                $n = 0;
                                $query = "Select * from Location";
                                $query1 = mysqli_query($con,$query);
                                while($res = mysqli_fetch_assoc($query1)){
                            ?>
                                    <option value="<?php echo $res['id'] ?>"><?php echo $res['Location'] ?></option>
                            <?php
                                }
                            ?>
                        </select>
                    </div>
                    <div class="field form-group">
                        <select class="form-control" name="bus_to">
                            <?php 
                                $n = 0;
                                $query = "Select * from Location";
                                $query1 = mysqli_query($con,$query);
                                while($res = mysqli_fetch_assoc($query1)){
                            ?>
                                    <option value="<?php echo $res['id'] ?>"><?php echo $res['Location'] ?></option>
                            <?php
                                }
                            ?>
                        </select>
                    </div>
                    
                    <div class="field form-group">
                        <input type="number" name="numSeats" class="form-control" placeholder="Number of Seats">
                    </div>
                    <div class="field form-group">
                        <input type="date" name="datetravel" class="form-control" >
                    </div>
                    
                </div>
                <button type="submit" name="check_bus" class="btn btn-gradient">Check Bus</button>
            </form>
        </div>
    </div>
    <div class="main-content">
        <h2>All Buses Scheduled for Today and Future Departures</h2>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Bus Name</th>
                    <th>Bus Number</th>
                    <th>Bus From</th>
                    <th>Bus To</th>
                    <th>Number of Seats</th>
                    <th>Available Seats</th>
                    <th>Date of Travel</th>
                    <?php if(isset($_POST['check_bus'])){ ?>
                            <th>Action</th>
                    <?php } ?>
                </tr>
            </thead>
            <tbody>
                    <?php 
                        $n = 0;
                        if(isset($_POST['check_bus'])){
                            $busFrom = $_POST['bus_from'];
                            $busTo = $_POST['bus_to'];
                            $date = $_POST['datetravel'];
                            $numSeats = $_POST['numSeats'];
                            $query = "Select b.id,busName, busNumber,noofseats, dateofTravel, l.location as busFrom,l1.location as busTo, seatsBooked from buses b inner join Location l on b.busFrom= l.id inner join Location l1 on b.busTo= l1.id where b.dateofTravel >= '$date' and b.busFrom='$busFrom' and b.busTo='$busTo' and (noofseats-seatsBooked) >$numSeats-1";
                        }else{
                            $query = "Select b.id,busName, busNumber,noofseats, dateofTravel, l.location as busFrom,l1.location as busTo, seatsBooked from buses b inner join Location l on b.busFrom= l.id inner join Location l1 on b.busTo= l1.id where b.dateofTravel >= CURRENT_DATE";           
                        }

                        $query1 = mysqli_query($con,$query);
                        while($res = mysqli_fetch_assoc($query1)){
                    ?>
                            <tr>
                                <td><?php $n = $n+1; echo $n;  ?></td>
                                <td><?php echo $res['busName']; ?></td>
                                <td><?php echo $res['busNumber']; ?></td>
                                <td><?php echo $res['busFrom']; ?></td>
                                <td><?php echo $res['busTo']; ?></td>
                                <td><?php echo $res['noofseats']; ?></td>
                                <td><?php echo $res['noofseats']-$res['seatsBooked']; ?></td>
                                <td><?php echo $res['dateofTravel']; ?></td>
                            <?php if(isset($_POST['check_bus'])){ ?>
                                <td><a href="bookabus.php?id=<?php echo $res['id']; ?>&qty=<?php echo $numSeats; ?>">Book Ticket</a></td>
                            <?php } ?>

                            </tr>
                    <?php
                        }
                    ?>
                
                <!-- Add more rows as necessary -->
            </tbody>
        </table>
    </div>

    <?php 
        include('in/footer.php');
    ?>
</body>

</html>
