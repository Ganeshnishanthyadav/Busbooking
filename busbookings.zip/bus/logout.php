<?php
//Logout
include('in/session.php');
session_destroy();
echo "<script type='text/javascript'>alert('User Logged Out') </script>";
echo "<script>window.location.href='index.php'</script>";
?>