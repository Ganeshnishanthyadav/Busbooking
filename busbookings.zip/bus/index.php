<?php
include('in/session.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php 
        include('in/head.php');
    ?>
    <style>
        /* Resetting some default browser styles */
        body, h1, h2, h3, p {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f6f8;
            color: #3a3a3a;
            display: flex; /* New */
            flex-direction: column; /* New */
            min-height: 100vh; /* New */
        }

        header {
            background: linear-gradient(45deg, #1a1a2e, #16213e);
            color: #e0e0e0;
            padding: 30px 0;
            text-align: center;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }

        nav {
            display: flex;
            justify-content: space-around;
            padding: 20px 0;
            background-color: #fff;
            box-shadow: 0px 2px 15px rgba(0, 0, 0, 0.08);
        }

            nav a {
                color: #5a5a5a;
                padding: 0 10px;
                text-decoration: none;
                font-weight: 500;
                transition: color 0.3s;
            }

                nav a:hover {
                    color: #333;
                }

        .banner {
            flex: 1; /* New */
            background-image: url('img/busticket.jpg');
            background-repeat: no-repeat;
            background-position: center;
            background-color: #f4f6f8;
            padding: 80px 0;
            text-align: center;
        }

            .banner h2 {
                margin-bottom: 20px;
                font-size: 2.5em;
            }

            .banner p {
                margin-bottom: 40px;
                font-size: 1.1em;
                color: #666;
            }

        .search-bar {
            max-width: 500px;
            margin: 0 auto;
            display: flex;
            border: 1px solid #ccc;
            border-radius: 50px;
            overflow: hidden;
            background-color: #fff;
        }

            .search-bar input {
                flex: 1;
                padding: 15px 20px;
                border: none;
                font-size: 1em;
                outline: none;
            }

            .search-bar button {
                padding: 15px 20px;
                border: none;
                background-color: #007bff;
                color: #fff;
                cursor: pointer;
                border-radius: 0 50px 50px 0;
                transition: background-color 0.3s;
            }

                .search-bar button:hover {
                    background-color: #0056b3;
                }

        footer {
            background-color: #1a1a2e;
            color: #e0e0e0;
            text-align: center;
            padding: 30px 0;
        }
    </style>
</head>

<body>
    

    <?php 
        include('in/header.php');
        include('in/nav.php');
    ?>

    <div class="banner">
        <h2></h2>
        <p></p>
        
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

   

    <?php 
        include('in/footer.php');
    ?>
</body>

</html>
